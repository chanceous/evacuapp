<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <base href="public">
    <title>EvacuApp Admistracion</title>

    <!-- Bootstrap core CSS -->

    <link href="css/app.css" rel="stylesheet">

  </head>
<style>
     #unipublish
      {
        background-color: pink;
        color: #FAFAFA;
        border-radius: 15px;
      }
      #botonalertar
      {
        background-color: red;
        color: #FAFAFA;
        border-radius: 200px;
        border: 0px solid white;
        height: 250px;
        width: 250px;
        font-size: 2em;
        font-weight: bold;
        margin-top: 25px;
      }
      .checkbox
      {
        margin-top: 35px;
      }
    </style>
  <body>
  <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="/">
                        EvacuApp <b>Admin</b>
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="admin">Admin</a></li>
                                                    <li><a href="login">Ingresar</a></li>
                            <li><a href="register">Registrarme</a></li>
                                            </ul>
                </div>
            </div>
        </nav>
<form class="alertarform" action="index.html" method="post">

    <!-- Page Content -->
    <div class="container">
      <div class="row">

        <div class="col-lg-6 text-center">
          <h1 class="mt-5">SENSORES</h1>
          <p class="lead"></p>
          <div id="unipublish" class="sensor col-lg-12 col-md-12 col-xs-12 col-sm-12">
            <div class="container">
              <div class="row">
                <h2 class="nombresensor col-lg-4 col-md-2 col-xs-2 col-sm-2">Nombre Sensor</h2>
                <h2 class="nivelsensor col-lg-2 col-md-2 col-xs-2 col-sm-2">Nivel</h2>
                <h2 class="iramapa col-lg-6 col-md-2 col-xs-2 col-sm-2"><a href="#">MAPA</a></h2>
              </div>
            </div>
          </div>

        </div>
        <div class="col-lg-6 text-center">
          <h1 class="mt-5">REFUGIOS</h1>
          <p class="lead"></p>
          <div id="unipublish" class="sensor col-lg-12 col-md-12 col-xs-12 col-sm-12">
            <div class="container">
              <div class="row">
                <input class="checkbox col-lg-1 col-md-2 col-xs-2 col-sm-2" type="checkbox" name="" value="">
                <h3 class="nombresensor col-lg-4 col-md-2 col-xs-2 col-sm-2">Nombre Refugio</h3>
                <h3 class="iramapa col-lg-6 col-md-2 col-xs-2 col-sm-2"><a href="#">MAPA</a></h3>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-12 text-center">
          <input type="button" id="botonalertar" value="ALERTAR" type="button" name="button">
        </div>
      </div>
    </div>
  </form>

    <!-- Bootstrap core JavaScript -->
    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
